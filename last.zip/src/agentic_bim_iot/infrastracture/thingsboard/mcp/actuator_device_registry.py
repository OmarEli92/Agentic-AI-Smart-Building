from agentic_bim_iot.application.interfaces.device_registry import DeviceRegistryError
from agentic_bim_iot.domain.actuator import ActuatorReference
from agentic_bim_iot.domain.iot import IoTActuatorDeviceReference
from agentic_bim_iot.infrastracture.observability.tracing import trace_observation
from agentic_bim_iot.infrastracture.thingsboard.mcp.client import ThingsBoardMCPClient, ThingsBoardMCPError
from agentic_bim_iot.infrastracture.thingsboard.mcp.payload import extract_device


class ThingsBoardMCPActuatorDeviceRegistry:
    """Resolve semantic actuator references through the ThingsBoard MCP server."""
    def __init__(self, client: ThingsBoardMCPClient) -> None:
        self._client = client

    def resolve(self, actuator: ActuatorReference) -> IoTActuatorDeviceReference:
        with trace_observation(
            "thingsboard.mcp.resolve_actuator_device",
            as_type="tool",
            input_payload={
                "actuator_guid": actuator.actuator_guid,
                "room_reference": actuator.room_reference,
                "measurement": actuator.controlled_measurement,
                "actuator_type": actuator.actuator_type
            },
        ) as observation:
            try:
                arguments = self._client.build_arguments(
                    "getTenantDevice",
                    {
                        "device_name": (("deviceName", "name", "device_name"), actuator.actuator_guid)
                    }
                )
                payload = self._client.call_tool("getTenantDevice", arguments)
                platform_device_id, platform_device_name = extract_device(payload, actuator.actuator_guid)
            except ThingsBoardMCPError as exc:
                raise DeviceRegistryError(f"No ThingsBoard device is found for the semantic actuator ID: {actuator.actuator_guid}") from exc

            reference = IoTActuatorDeviceReference(
                semantic_actuator_guid=actuator.actuator_guid,
                platform_device_id=platform_device_id,
                platform_device_name=platform_device_name
            )
            observation.update(
                output={
                    "platform_device_id": reference.platform_device_id,
                    "platform_device_name": reference.platform_device_name,
                }
            )
            return reference
