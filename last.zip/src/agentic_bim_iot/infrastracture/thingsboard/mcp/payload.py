import json
from typing import Any
from agentic_bim_iot.infrastracture.thingsboard.mcp.client import ThingsBoardMCPError


def unwrap_payload(payload: Any) -> Any:
    """Remove unncessary informations that comes as MCP response wrappers and we dont need for our case study"""
    current = payload
    while True:
        if isinstance(current, str):
            stripped = current.strip()
            if not stripped:
                return current
            try:
                decoded = json.loads(stripped)
            except json.JSONDecodeError:
                return current
            if decoded == current:
                return current
            current = decoded
            continue
        if isinstance(current, dict) and len(current) == 1:
            key = next(iter(current))
            if key.casefold() in {"result", "data", "content", "value"}:
                current = current[key]
                continue
        return current


def extract_device(payload: Any, expected_name: str) -> tuple[str, str]:
    """Extract a device ID and name from an MCP payload."""
    candidate = _find_device_candidate(unwrap_payload(payload), expected_name)
    if candidate is None:
        raise ThingsBoardMCPError(f"ThingsBoard did not return device '{expected_name}'.")
    device_id = _extract_entity_id(candidate.get("id"))
    device_name = candidate.get("name")
    if not device_id:
        raise ThingsBoardMCPError("ThingsBoard returned a device without an ID.")
    if not isinstance(device_name, str) or not device_name.strip():
        device_name = expected_name
    return device_id, device_name


def extract_latest_telemetry(payload: Any, telemetry_key: str) -> tuple[Any, int]:
    """Extract the latest telemetry value and timestamp from a payload."""
    normalized = unwrap_payload(payload)
    values = _find_telemetry_values(normalized, telemetry_key)
    if values is None:
        raise ThingsBoardMCPError(f"No telemetry is available for the key '{telemetry_key}'.")
    values = unwrap_payload(values)
    if isinstance(values, list):
        if not values:
            raise ThingsBoardMCPError(f"No telemetry is available for the key '{telemetry_key}'.")
        latest = unwrap_payload(values[0])
    else:
        latest = values
    if isinstance(latest, dict):
        timestamp = latest.get("ts", latest.get("timestamp", latest.get("timestampMs")))
        value = latest.get("value")
    else:
        timestamp = None
        value = latest
    if timestamp is None:
        raise ThingsBoardMCPError("ThingsBoard  returned telemetry without a timestamp.")
    try:
        timestamp_ms = int(timestamp)
    except (TypeError, ValueError) as exc:
        raise ThingsBoardMCPError("ThingsBoard returned an invalid telemetry timestamp.") from exc
    return value, timestamp_ms


def _find_device_candidate(payload: Any, expected_name: str) -> dict[str, Any] | None:
    payload = unwrap_payload(payload)
    if isinstance(payload, dict):
        name = payload.get("name")
        entity_id = payload.get("id")
        if entity_id is not None and isinstance(name, str) and name.casefold() == expected_name.casefold():
            return payload
        if entity_id is not None and name is not None:
            return payload
        for value in payload.values():
            candidate = _find_device_candidate(value, expected_name)
            if candidate is not None:
                return candidate
    if isinstance(payload, list):
        for value in payload:
            candidate = _find_device_candidate(value, expected_name)
            if candidate is not None:
                return candidate
    return None


def _extract_entity_id(value: Any) -> str | None:
    value = unwrap_payload(value)
    if isinstance(value, str) and value.strip():
        return value
    if isinstance(value, dict):
        direct = value.get("id")
        if isinstance(direct, str) and direct.strip():
            return direct
        for nested in value.values():
            extracted = _extract_entity_id(nested)
            if extracted:
                return extracted

    return None


def _find_telemetry_values(payload: Any, telemetry_key: str) -> Any | None:
    payload = unwrap_payload(payload)
    if isinstance(payload, dict):
        for key, value in payload.items():
            if str(key).casefold() == telemetry_key.casefold():
                return value
        for value in payload.values():
            found = _find_telemetry_values(value, telemetry_key)
            if found is not None:
                return found
    if isinstance(payload, list):
        for value in payload:
            found = _find_telemetry_values(value, telemetry_key)
            if found is not None:
                return found

    return None
