import json
from typing import Any
from agentic_bim_iot.infrastracture.thingsboard.mcp.client import ThingsBoardMCPError


def normalize_payload(payload: Any) -> Any:
    """Normalize a ThingsBoard MCP response."""
    if isinstance(payload, str):
        value = payload.strip()
        if not value:
            return None
        try:
            return normalize_payload(json.loads(value))

        except json.JSONDecodeError:
            return value

    if isinstance(payload, dict):
        if len(payload) == 1 and "result" in payload:
            return normalize_payload(payload["result"])
        if len(payload) == 1 and "data" in payload:
            return normalize_payload(payload["data"])
    return payload


def extract_device(payload: Any, expected_name: str) -> tuple[str, str]:
    """Extract a ThingsBoard device."""
    device = normalize_payload(payload)
    if not isinstance(device, dict):
        raise ThingsBoardMCPError(f"ThingsBoard MCP did not return device '{expected_name}'.")
    raw_id = device.get("id")
    if isinstance(raw_id, dict):
        device_id = raw_id.get("id")
    else:
        device_id = raw_id
    if not isinstance(device_id, str) or not device_id.strip():
        raise ThingsBoardMCPError("ThingsBoard MCP returned a device without an ID.")
    device_name = device.get("name")
    if not isinstance(device_name, str) or not device_name.strip():
        device_name = expected_name
    return (device_id, device_name)


def extract_latest_telemetry(payload: Any, telemetry_key: str) -> tuple[Any, int]:
    """Extract the latest telemetry value."""
    telemetry = normalize_payload(payload)
    if not isinstance(telemetry, dict):
        raise ThingsBoardMCPError("ThingsBoard MCP returned an invalid telemetry payload.")
    values = telemetry.get(telemetry_key)
    if not isinstance(values, list) or not values:
        raise ThingsBoardMCPError(f"No telemetry is available for the key '{telemetry_key}'.")
    latest = values[0]
    if not isinstance(latest, dict):
        raise ThingsBoardMCPError("ThingsBoard MCP returned an invalid telemetry value.")
    timestamp = latest.get("ts")
    if timestamp is None:
        raise ThingsBoardMCPError("ThingsBoard MCP returned telemetry without a timestamp.")
    try:
        timestamp_ms = int(timestamp)

    except (TypeError, ValueError) as exc:
        raise ThingsBoardMCPError("ThingsBoard MCP returned an invalid telemetry timestamp.") from exc
    return (latest.get("value"), timestamp_ms)


def ensure_successful_write(payload: Any) -> None:
    """Validate a ThingsBoard MCP write."""
    result = normalize_payload(payload)
    if result is None:
        return
    if not isinstance(result, dict):
        raise ThingsBoardMCPError("ThingsBoard MCP returned an invalid write result.")
    status = str(result.get("status","")).strip()
    if not status:
        return
    normalized_status = status.casefold()
    if "failed" in normalized_status or "error" in normalized_status:
        raise ThingsBoardMCPError(status)