from pydantic import BaseModel, ConfigDict, Field

class SemanticQueryResult(BaseModel):
    """This class represent the normalized result returned by the semantic subsytem.
    In the sense that the application shouldn't depend on the output format of the LangChain/ GraphDB implementation
    At the actual state the subsystem is the retrieval information system already build using langchain (our starting point)"""
    
    model_config = ConfigDict(extra="forbid")
    answer: str = Field(
        min_length=1,
        description="Natural language answer grounded in the semantic graph"    
    )
    
    
    