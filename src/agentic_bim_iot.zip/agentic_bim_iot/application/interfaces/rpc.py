from typing import Any, Protocol


class TwoWayRpcTransport(Protocol):
    """The contract for synchronous server-to-device RPC commands."""

    def call_two_way(self, *, device_id: str, method: str, params: dict[str, Any], timeout_ms: int) -> Any:
        ...